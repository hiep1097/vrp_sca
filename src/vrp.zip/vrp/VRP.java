package vrp;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class VRP{
    public float infinity = 100000;
    public List<Customer> customers = new ArrayList<>();
    public List<Vehicle> vehicles = new ArrayList<>();
    List<CustomerSchedule> customerSchedules;
    public int N;  //number of customer
    public int V;  //number of vehicle
    public float c[][];
    public int x[][];

    public float RES = 0;
    public double[] x_rand;

    public VRP() {
        readData("Data/30customer.txt");
        x = new int[N+1][N+1];
        //print_matrix(c, N+1);
//        System.out.println("So khach hang: "+N);
//        for (Customer customer: customers){
//            System.out.println("Name: "+customer.getName() + " - Demand: "+customer.getDemand());
//        }
//        System.out.println();
//        System.out.println("So xe: "+V);
//        for (Vehicle vehicle: vehicles){
//            System.out.println("Name: "+vehicle.getName() + " - Capacity: "+vehicle.getCapacity());
//        }
    }

    public double Execute(double x[]) {
        x_rand = x;
        ExecuteAlgorithm();
        return RES;
    }

    public void printRoute(){
        System.out.println("Result: "+ RES);
        System.out.println("Rout is: ");
        for (int k=0; k<V; k++){
            System.out.print("0->");
            for (int i = k*6; i < (k+1) * 6; i++){
                System.out.print(customerSchedules.get(i).customerName+"->");
            }
            System.out.print("0");
            System.out.println();
        }
    }

    public void ExecuteAlgorithm(){
        //Thực hiện khởi tạo quần thể sắp lịch ban đầu từ kết quả của thuật toán GWO thông qua x_rand[]
        customerSchedules = new ArrayList<CustomerSchedule>();
        for(int i = 0; i < customers.size(); i++){
            CustomerSchedule customerSchedule = new CustomerSchedule();
            customerSchedule.customerName = customers.get(i).name;
            customerSchedule.customerValue = (int) (x_rand[i] * 10000);
            customerSchedules.add(customerSchedule);
        }

        // Dựa và giá trị value của dãy Random/Thuật toán GWO, sắp sếp lại thứ tự đổ tại các công trường
//        for(int i = 0; i < customerSchedules.size() - 1; i++){
//            for(int j = i + 1; j < customerSchedules.size(); j++){
//                if( customerSchedules.get(i).customerValue > customerSchedules.get(j).customerValue){
//                    String tempName = customerSchedules.get(i).customerName;
//                    int tempValue = customerSchedules.get(i).customerValue;
//
//                    customerSchedules.get(i).customerName = customerSchedules.get(j).customerName;
//                    customerSchedules.get(i).customerValue = customerSchedules.get(j).customerValue;
//
//                    customerSchedules.get(j).customerName = tempName;
//                    customerSchedules.get(j).customerValue = tempValue;
//                }
//            }
//        }

        RES = infinity;
        float sum = 0;

        //V = 5 xe
        for (int k = 0; k<V; k++){
            for (int i = k*6; i < (k+1) * 6; i++) {
                if (i == k*6){
                    Customer customer = getCustomerByName(customerSchedules.get(i).customerName);
                    if (vehicles.get(k).capacity-customer.demand >= 0) {
                        vehicles.get(k).capacity = vehicles.get(k).capacity- customer.demand;
                        sum = sum + c[0][customer.position];
                    } else {
                        RES = infinity;
                        return;
                    }
                } else {
                    Customer customer1 = getCustomerByName(customerSchedules.get(i).customerName);
                    Customer customer2 = getCustomerByName(customerSchedules.get(i-1).customerName);
                    if (vehicles.get(k).capacity-customer1.demand >= 0){
                        vehicles.get(k).capacity = vehicles.get(k).capacity- customer1.demand;
                        sum = sum + c[customer1.position][customer2.position];
                    } else {
                        RES = infinity;
                        return;
                    }
                }
                if (i == (k+1)*6 - 1){
                    Customer customer = getCustomerByName(customerSchedules.get(i).customerName);
                    sum = sum+c[0][customer.position];
                }
            }
        }
        RES = sum;
    }

    public void readData(String fileName) {
        try {
            File f = new File(fileName);
            Scanner scan = new Scanner(f);
            N = scan.nextInt();
            c = new float[N+1][N+1];    //distance between customers

            for (int i=1; i<=N; i++){
                int demand = scan.nextInt();
                customers.add(new Customer("Customer "+i, demand, i));
            }

            for (int i=0; i<=N; i++){
                for (int j=0; j<=N; j++){
                    c[i][j] = scan.nextFloat();
                    if (c[i][j] == -1.0){
                        c[i][j] = infinity;
                    }
                }
            }

            V = scan.nextInt();
            for (int i=1; i<=V; i++){
                int capacity = scan.nextInt();
                vehicles.add(new Vehicle("Vehicle "+(char)+(97+i-1), capacity));
            }
        } catch (Exception e){
            System.out.println("Error when read data: "+e.getMessage());
        }


    }

    public void print_matrix(int a[][], int length){
        for (int i=0; i<length; i++){
            for (int j=0; j<length; j++) System.out.print(a[i][j] + "\t\t");
            System.out.println();
        }
    }

    public Customer getCustomerByName(String name){
        return customers.stream()
                .filter(customer -> customer.name.equals(name))
                .findFirst()
                .orElse(null);
    }
}
