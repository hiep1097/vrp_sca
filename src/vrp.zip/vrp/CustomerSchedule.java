package vrp;

public class CustomerSchedule {
    public String customerName;
    public int customerValue;
    public String vehicleName;
}
