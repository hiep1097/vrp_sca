package vrp;

import java.io.IOException;

public abstract class f_xj {
    public abstract double func(double x[]);
}
